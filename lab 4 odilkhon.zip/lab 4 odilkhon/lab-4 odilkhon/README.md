# Lab 4: Create your Music List

You need to use given repo to create your music list.

### Student Details

- **Student ID**: U1610050
- **Student Name**: Bekzod Erkinov
- **Section Number**: 001 (ICE-16-1)
